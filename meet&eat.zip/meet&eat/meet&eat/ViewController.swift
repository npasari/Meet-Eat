//
//  ViewController.swift
//  meet&eat
//
//  Created by Rueya Egemenoglu on 10/26/19.
//  Copyright © 2019 Rueya Egemenoglu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

